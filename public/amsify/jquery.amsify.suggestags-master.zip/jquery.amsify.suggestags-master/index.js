global.$ = global.jQuery = require('jquery');
require('./js/jquery.amsify.suggestags');
exports.AmsifySuggestags = AmsifySuggestags;